import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../services/auth_service.dart';
import '../widgets/common_widgets.dart';

class SetupScreen extends StatefulWidget {
  const SetupScreen({super.key});

  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  final AuthService _auth = AuthService();
  final TextEditingController _phraseCtrl = TextEditingController(text: 'Open DualLock');

  bool _faceSaved = false;
  bool _phraseSaved = false;

  @override
  void initState() {
    super.initState();
    _loadCurrent();
  }

  Future<void> _loadCurrent() async {
    final hasFace = await _auth.hasFaceEnrolled();
    final phrase = await _auth.getEnrolledPhrase();
    setState(() {
      _faceSaved = hasFace;
      _phraseCtrl.text = phrase;
    });
  }

  Future<void> _saveFace() async {
    // In production: capture actual face embedding from camera
    // Here we save a placeholder hash
    await _auth.enrollFace('demo_face_hash_${DateTime.now().millisecondsSinceEpoch}');
    setState(() => _faceSaved = true);
    _showSnack('✅ Face enroll ho gaya!');
  }

  Future<void> _savePhrase() async {
    final phrase = _phraseCtrl.text.trim();
    if (phrase.isEmpty) {
      _showSnack('❌ Phrase khali nahi ho sakta');
      return;
    }
    await _auth.setEnrolledPhrase(phrase);
    setState(() => _phraseSaved = true);
    _showSnack('✅ Phrase save ho gaya: "$phrase"');
  }

  Future<void> _clearAll() async {
    await _auth.clearEnrolled();
    setState(() {
      _faceSaved = false;
      _phraseSaved = false;
      _phraseCtrl.text = 'Open DualLock';
    });
    _showSnack('🗑️ Sab data clear ho gaya');
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: GoogleFonts.spaceMono(fontSize: 12)),
        backgroundColor: AppTheme.card,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Setup & Enroll'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Pehli baar setup karo',
                style: GoogleFonts.syne(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  color: AppTheme.textPrimary,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'Apna chehra aur voice phrase register karo.',
                style: GoogleFonts.spaceMono(fontSize: 11, color: AppTheme.textMuted),
              ),

              const SizedBox(height: 28),

              // Face enrollment
              _SetupSection(
                icon: Icons.face_retouching_natural,
                title: 'Face Enroll',
                subtitle: 'Apna chehra register karo',
                color: AppTheme.accent,
                isComplete: _faceSaved,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (_faceSaved)
                      CheckItem(label: 'Face enrolled hai ✓', state: CheckState.ok)
                    else
                      CheckItem(label: 'Face enrolled nahi hai', state: CheckState.pending),
                    const SizedBox(height: 12),
                    GlowButton(
                      label: _faceSaved ? 'Dobara Enroll Karo' : 'Face Enroll Karo',
                      icon: Icons.camera_alt_rounded,
                      onTap: _saveFace,
                      color: AppTheme.accent,
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // Voice phrase
              _SetupSection(
                icon: Icons.mic_rounded,
                title: 'Voice Phrase',
                subtitle: 'Apna unlock phrase set karo',
                color: AppTheme.accent2,
                isComplete: _phraseSaved,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Unlock phrase:',
                      style: GoogleFonts.spaceMono(
                        fontSize: 11,
                        color: AppTheme.textMuted,
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _phraseCtrl,
                      style: GoogleFonts.spaceMono(
                        color: AppTheme.textPrimary,
                        fontSize: 13,
                      ),
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: AppTheme.surface,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: AppTheme.border),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: AppTheme.border),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: AppTheme.accent),
                        ),
                        hintText: 'e.g. Open DualLock',
                        hintStyle: GoogleFonts.spaceMono(
                          color: AppTheme.textMuted,
                          fontSize: 12,
                        ),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                      ),
                    ),
                    const SizedBox(height: 12),
                    GlowButton(
                      label: 'Phrase Save Karo',
                      icon: Icons.save_rounded,
                      onTap: _savePhrase,
                      color: AppTheme.accent2,
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 28),

              // Info box
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppTheme.card,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppTheme.border),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '💡 Tips',
                      style: GoogleFonts.syne(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.accent,
                      ),
                    ),
                    const SizedBox(height: 10),
                    _Tip('Acchi roshni mein face enroll karo'),
                    _Tip('Phrase unique aur yaad rakhne wala rakho'),
                    _Tip('English phrase best kaam karta hai recognition ke liye'),
                    _Tip('Phrase kam se kam 2-3 words ka hona chahiye'),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              // Clear button
              GlowButton(
                label: 'Sab Data Clear Karo',
                icon: Icons.delete_outline_rounded,
                onTap: _showClearDialog,
                outline: true,
              ),

              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  void _showClearDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Sure ho?', style: GoogleFonts.syne(color: AppTheme.textPrimary, fontWeight: FontWeight.w800)),
        content: Text(
          'Face aur phrase data delete ho jayega.',
          style: GoogleFonts.spaceMono(color: AppTheme.textMuted, fontSize: 12),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: GoogleFonts.spaceMono(color: AppTheme.textMuted)),
          ),
          TextButton(
            onPressed: () { Navigator.pop(context); _clearAll(); },
            child: Text('Delete', style: GoogleFonts.spaceMono(color: AppTheme.danger)),
          ),
        ],
      ),
    );
  }
}

class _SetupSection extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final bool isComplete;
  final Widget child;

  const _SetupSection({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.isComplete,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: isComplete ? color.withOpacity(0.4) : AppTheme.border,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: color, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: GoogleFonts.syne(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.textPrimary,
                      ),
                    ),
                    Text(
                      subtitle,
                      style: GoogleFonts.spaceMono(
                        fontSize: 10,
                        color: AppTheme.textMuted,
                      ),
                    ),
                  ],
                ),
              ),
              if (isComplete)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppTheme.success.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    '✓ Done',
                    style: GoogleFonts.spaceMono(
                      fontSize: 9,
                      color: AppTheme.success,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 16),
          child,
        ],
      ),
    );
  }
}

class _Tip extends StatelessWidget {
  final String text;
  const _Tip(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('• ', style: GoogleFonts.spaceMono(color: AppTheme.accent, fontSize: 11)),
          Expanded(
            child: Text(
              text,
              style: GoogleFonts.spaceMono(color: AppTheme.textMuted, fontSize: 11, height: 1.5),
            ),
          ),
        ],
      ),
    );
  }
}
