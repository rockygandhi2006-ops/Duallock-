import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../widgets/common_widgets.dart';
import 'face_scan_screen.dart';
import 'setup_screen.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    _fadeAnim = Tween(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _ctrl, curve: const Interval(0, 0.6, curve: Curves.easeOut)),
    );
    _slideAnim = Tween(begin: const Offset(0, 0.2), end: Offset.zero).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeOut),
    );
    _ctrl.forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnim,
          child: SlideTransition(
            position: _slideAnim,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Top row
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _LockIcon(),
                      TextButton(
                        onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const SetupScreen()),
                        ),
                        child: Text(
                          'Setup',
                          style: GoogleFonts.spaceMono(
                            color: AppTheme.textMuted,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ],
                  ),

                  const Spacer(),

                  // Title
                  Text(
                    'DUAL\nLOCK',
                    style: GoogleFonts.syne(
                      fontSize: 56,
                      fontWeight: FontWeight.w800,
                      height: 0.95,
                      foreground: Paint()
                        ..shader = const LinearGradient(
                          colors: [AppTheme.accent, AppTheme.accent2],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ).createShader(const Rect.fromLTWH(0, 0, 200, 100)),
                    ),
                  ),

                  const SizedBox(height: 16),

                  Text(
                    'Face + Voice — dono zaroori hain.',
                    style: GoogleFonts.spaceMono(
                      color: AppTheme.textMuted,
                      fontSize: 13,
                    ),
                  ),

                  const SizedBox(height: 40),

                  // Feature cards
                  _FeatureRow(
                    icon: Icons.face_retouching_natural,
                    title: 'Face Recognition',
                    sub: 'ML Kit se real-time chehra detect',
                    color: AppTheme.accent,
                  ),
                  const SizedBox(height: 12),
                  _FeatureRow(
                    icon: Icons.mic_rounded,
                    title: 'Voice Recognition',
                    sub: 'Aapka khaas phrase sunta hai',
                    color: AppTheme.accent2,
                  ),
                  const SizedBox(height: 12),
                  _FeatureRow(
                    icon: Icons.verified_user_rounded,
                    title: 'Dual Auth Required',
                    sub: 'Ek bhi fail — access band',
                    color: AppTheme.success,
                  ),

                  const Spacer(),

                  // CTA
                  GlowButton(
                    label: 'Unlock Karo',
                    icon: Icons.lock_open_rounded,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const FaceScanScreen()),
                    ),
                  ),
                  const SizedBox(height: 12),
                  GlowButton(
                    label: 'Setup / Enroll',
                    icon: Icons.settings_rounded,
                    outline: true,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const SetupScreen()),
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _LockIcon extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 48,
      height: 48,
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.border),
        boxShadow: [BoxShadow(color: AppTheme.accent.withOpacity(0.15), blurRadius: 12)],
      ),
      child: const Icon(Icons.lock_rounded, color: AppTheme.accent, size: 22),
    );
  }
}

class _FeatureRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final String sub;
  final Color color;

  const _FeatureRow({
    required this.icon,
    required this.title,
    required this.sub,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.border),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.syne(
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                    color: AppTheme.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  sub,
                  style: GoogleFonts.spaceMono(
                    fontSize: 10,
                    color: AppTheme.textMuted,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
