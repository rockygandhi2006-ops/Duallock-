import 'dart:async';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:permission_handler/permission_handler.dart';
import '../theme/app_theme.dart';
import '../services/auth_service.dart';
import '../widgets/common_widgets.dart';
import 'voice_scan_screen.dart';

class FaceScanScreen extends StatefulWidget {
  const FaceScanScreen({super.key});

  @override
  State<FaceScanScreen> createState() => _FaceScanScreenState();
}

class _FaceScanScreenState extends State<FaceScanScreen>
    with SingleTickerProviderStateMixin {
  final AuthService _auth = AuthService();

  CameraController? _camera;
  List<CameraDescription> _cameras = [];

  bool _isCameraReady = false;
  bool _isScanning = false;
  bool _faceDetected = false;
  bool _faceVerified = false;

  String _statusText = 'Camera shuru karo';
  BadgeState _badgeState = BadgeState.idle;

  CheckState _lightCheck = CheckState.pending;
  CheckState _faceCheck = CheckState.pending;
  CheckState _verifyCheck = CheckState.pending;

  late AnimationController _scanAnim;
  Timer? _scanTimer;
  int _frameCount = 0;

  @override
  void initState() {
    super.initState();
    _scanAnim = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat();
  }

  @override
  void dispose() {
    _camera?.dispose();
    _auth.dispose();
    _scanAnim.dispose();
    _scanTimer?.cancel();
    super.dispose();
  }

  Future<void> _startCamera() async {
    final permission = await Permission.camera.request();
    if (!permission.isGranted) {
      _showSnack('❌ Camera permission chahiye!');
      return;
    }

    setState(() {
      _isScanning = true;
      _badgeState = BadgeState.scanning;
      _statusText = 'Camera start ho raha hai...';
    });

    try {
      _cameras = await availableCameras();
      // Prefer front camera
      final frontCam = _cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.front,
        orElse: () => _cameras.first,
      );

      _camera = CameraController(
        frontCam,
        ResolutionPreset.medium,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.nv21,
      );

      await _camera!.initialize();

      if (!mounted) return;
      setState(() {
        _isCameraReady = true;
        _lightCheck = CheckState.ok;
        _statusText = 'Chehra saamne rakho...';
      });

      // Start face detection stream
      _camera!.startImageStream(_processCameraImage);
    } catch (e) {
      _showSnack('Camera error: $e');
      setState(() {
        _isScanning = false;
        _badgeState = BadgeState.failed;
      });
    }
  }

  void _processCameraImage(CameraImage image) async {
    _frameCount++;
    if (_frameCount % 10 != 0) return; // Process every 10th frame
    if (_faceVerified) return;

    final rotation = _camera!.description.sensorOrientation == 90
        ? InputImageRotation.rotation90deg
        : InputImageRotation.rotation270deg;

    try {
      final faces = await _auth.detectFaces(image, rotation);

      if (!mounted) return;

      if (faces.isNotEmpty) {
        final valid = faces.any(_auth.isFaceValid);
        setState(() {
          _faceDetected = true;
          _faceCheck = CheckState.ok;
          _statusText = valid ? 'Verify ho raha hai...' : 'Seedha dekho...';
        });

        if (valid && !_faceVerified) {
          await _verifyFace();
        }
      } else {
        if (_faceDetected) {
          setState(() {
            _faceDetected = false;
            _faceCheck = CheckState.pending;
            _statusText = 'Chehra frame mein rakho...';
          });
        }
      }
    } catch (_) {}
  }

  Future<void> _verifyFace() async {
    setState(() {
      _faceVerified = true;
      _verifyCheck = CheckState.ok;
      _badgeState = BadgeState.success;
      _statusText = 'Face verified! ✓';
    });

    await _camera?.stopImageStream();
    _showSnack('✅ Face match hua!');

    await Future.delayed(const Duration(milliseconds: 800));
    if (!mounted) return;

    Navigator.pushReplacement(
      context,
      PageRouteBuilder(
        pageBuilder: (_, a, __) => const VoiceScanScreen(),
        transitionsBuilder: (_, a, __, child) => SlideTransition(
          position: Tween(begin: const Offset(1, 0), end: Offset.zero).animate(a),
          child: child,
        ),
      ),
    );
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: GoogleFonts.spaceMono(fontSize: 12)),
        backgroundColor: AppTheme.card,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Face Scan'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Step indicator
              const StepIndicator(current: 1, total: 2),
              const SizedBox(height: 20),

              // Title
              Text(
                'Step 1 — Face',
                style: GoogleFonts.syne(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  color: AppTheme.textPrimary,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Camera ke saamne apna chehra rakho.\nAcchi roshni mein baithe.',
                style: GoogleFonts.spaceMono(
                  fontSize: 11,
                  color: AppTheme.textMuted,
                  height: 1.6,
                ),
              ),
              const SizedBox(height: 16),

              // Status badge
              StatusBadge(label: _statusText, state: _badgeState),
              const SizedBox(height: 16),

              // Camera preview
              Expanded(
                child: SectionCard(
                  padding: EdgeInsets.zero,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        // Camera or placeholder
                        if (_isCameraReady && _camera != null)
                          CameraPreview(_camera!)
                        else
                          _CameraPlaceholder(onTap: _startCamera),

                        // Scan overlay
                        if (_isScanning && _isCameraReady)
                          _ScanOverlay(
                            animation: _scanAnim,
                            faceDetected: _faceDetected,
                          ),
                      ],
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 16),

              // Check list
              CheckItem(label: 'Roshni theek hai', state: _lightCheck),
              CheckItem(label: 'Chehra detect hua', state: _faceCheck),
              CheckItem(label: 'Face verified', state: _verifyCheck),

              const SizedBox(height: 12),

              if (!_isCameraReady)
                GlowButton(
                  label: 'Camera Shuru Karo',
                  icon: Icons.camera_alt_rounded,
                  onTap: _isScanning ? null : _startCamera,
                ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Camera Placeholder ───────────────────────────────────────────────────────
class _CameraPlaceholder extends StatelessWidget {
  final VoidCallback onTap;
  const _CameraPlaceholder({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        color: AppTheme.surface,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.camera_alt_outlined, size: 48, color: AppTheme.textMuted.withOpacity(0.4)),
            const SizedBox(height: 12),
            Text(
              'Camera band hai\nChlane ke liye tap karo',
              textAlign: TextAlign.center,
              style: GoogleFonts.spaceMono(
                fontSize: 11,
                color: AppTheme.textMuted,
                height: 1.6,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Scan Overlay ─────────────────────────────────────────────────────────────
class _ScanOverlay extends StatelessWidget {
  final Animation<double> animation;
  final bool faceDetected;

  const _ScanOverlay({required this.animation, required this.faceDetected});

  @override
  Widget build(BuildContext context) {
    final frameColor = faceDetected ? AppTheme.success : AppTheme.accent;
    return Stack(
      children: [
        // Scan line
        AnimatedBuilder(
          animation: animation,
          builder: (_, __) {
            return Positioned(
              top: animation.value * MediaQuery.of(context).size.height * 0.4,
              left: 0,
              right: 0,
              child: Container(
                height: 2,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.transparent, frameColor, Colors.transparent],
                  ),
                  boxShadow: [BoxShadow(color: frameColor.withOpacity(0.6), blurRadius: 6)],
                ),
              ),
            );
          },
        ),

        // Face frame corners
        Center(
          child: SizedBox(
            width: 160,
            height: 200,
            child: CustomPaint(painter: _CornerPainter(color: frameColor)),
          ),
        ),
      ],
    );
  }
}

class _CornerPainter extends CustomPainter {
  final Color color;
  _CornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    const len = 20.0;

    // Top-left
    canvas.drawLine(Offset.zero, const Offset(len, 0), paint);
    canvas.drawLine(Offset.zero, const Offset(0, len), paint);

    // Top-right
    canvas.drawLine(Offset(size.width, 0), Offset(size.width - len, 0), paint);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width, len), paint);

    // Bottom-left
    canvas.drawLine(Offset(0, size.height), Offset(len, size.height), paint);
    canvas.drawLine(Offset(0, size.height), Offset(0, size.height - len), paint);

    // Bottom-right
    canvas.drawLine(Offset(size.width, size.height), Offset(size.width - len, size.height), paint);
    canvas.drawLine(Offset(size.width, size.height), Offset(size.width, size.height - len), paint);
  }

  @override
  bool shouldRepaint(_CornerPainter old) => old.color != color;
}
