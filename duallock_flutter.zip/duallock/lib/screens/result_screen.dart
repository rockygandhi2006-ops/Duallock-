import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../widgets/common_widgets.dart';
import 'welcome_screen.dart';

class ResultScreen extends StatefulWidget {
  final bool success;
  final String? failReason;

  const ResultScreen({super.key, required this.success, this.failReason});

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scaleAnim;
  late Animation<double> _fadeAnim;

  Timer? _sessionTimer;
  double _sessionProgress = 1.0;
  static const int _sessionSeconds = 30;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _scaleAnim = Tween(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut),
    );
    _fadeAnim = Tween(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _ctrl, curve: const Interval(0, 0.4)),
    );
    _ctrl.forward();

    if (widget.success) _startSessionTimer();
  }

  void _startSessionTimer() {
    const interval = Duration(milliseconds: 500);
    int elapsed = 0;
    _sessionTimer = Timer.periodic(interval, (t) {
      elapsed += 500;
      final progress = 1.0 - (elapsed / (_sessionSeconds * 1000));
      if (progress <= 0) {
        t.cancel();
        _autoLock();
      } else {
        setState(() => _sessionProgress = progress);
      }
    });
  }

  void _autoLock() {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('⏱️ Session expire — lock ho gaya', style: GoogleFonts.spaceMono(fontSize: 12)),
        backgroundColor: AppTheme.card,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
    _goHome();
  }

  void _goHome() {
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const WelcomeScreen()),
      (route) => false,
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _sessionTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final color = widget.success ? AppTheme.success : AppTheme.danger;
    final icon = widget.success ? '🔓' : '🚫';
    final title = widget.success ? 'Access Mila!' : 'Access Deny!';

    return Scaffold(
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnim,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
            child: Column(
              children: [
                const Spacer(),

                // Icon
                ScaleTransition(
                  scale: _scaleAnim,
                  child: Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: color.withOpacity(0.1),
                      border: Border.all(color: color, width: 2),
                      boxShadow: [BoxShadow(color: color.withOpacity(0.25), blurRadius: 40)],
                    ),
                    child: Center(
                      child: Text(icon, style: const TextStyle(fontSize: 40)),
                    ),
                  ),
                ),

                const SizedBox(height: 24),

                Text(
                  title,
                  style: GoogleFonts.syne(
                    fontSize: 30,
                    fontWeight: FontWeight.w800,
                    color: color,
                  ),
                ),

                const SizedBox(height: 12),

                if (widget.success)
                  Text(
                    'Aapka face aur voice dono\nverify ho gaye. Welcome!',
                    textAlign: TextAlign.center,
                    style: GoogleFonts.spaceMono(
                      fontSize: 12,
                      color: AppTheme.textMuted,
                      height: 1.7,
                    ),
                  )
                else
                  Text(
                    widget.failReason ?? 'Authentication fail ho gayi.\nDobara koshish karein.',
                    textAlign: TextAlign.center,
                    style: GoogleFonts.spaceMono(
                      fontSize: 11,
                      color: AppTheme.textMuted,
                      height: 1.7,
                    ),
                  ),

                const SizedBox(height: 32),

                // Check results
                SectionCard(
                  child: Column(
                    children: [
                      CheckItem(
                        label: 'Face Recognition',
                        state: CheckState.ok,
                      ),
                      CheckItem(
                        label: 'Voice Recognition',
                        state: widget.success ? CheckState.ok : CheckState.fail,
                      ),
                      CheckItem(
                        label: 'Dual Authentication',
                        state: widget.success ? CheckState.ok : CheckState.fail,
                      ),
                    ],
                  ),
                ),

                // Session timer (success only)
                if (widget.success) ...[
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: AppTheme.card,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppTheme.success.withOpacity(0.2)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '⏱️ Session active — ${(_sessionSeconds * _sessionProgress).round()}s bachi',
                          style: GoogleFonts.spaceMono(
                            fontSize: 10,
                            color: AppTheme.textMuted,
                          ),
                        ),
                        const SizedBox(height: 8),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(4),
                          child: LinearProgressIndicator(
                            value: _sessionProgress,
                            backgroundColor: AppTheme.border,
                            valueColor: AlwaysStoppedAnimation(AppTheme.success),
                            minHeight: 4,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],

                const Spacer(),

                GlowButton(
                  label: widget.success ? 'Lock Karo' : 'Dobara Try Karo',
                  icon: widget.success ? Icons.lock_rounded : Icons.refresh_rounded,
                  onTap: _goHome,
                  color: widget.success ? AppTheme.accent : AppTheme.danger,
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
