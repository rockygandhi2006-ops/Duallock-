import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:permission_handler/permission_handler.dart';
import '../theme/app_theme.dart';
import '../services/auth_service.dart';
import '../widgets/common_widgets.dart';
import 'result_screen.dart';

class VoiceScanScreen extends StatefulWidget {
  const VoiceScanScreen({super.key});

  @override
  State<VoiceScanScreen> createState() => _VoiceScanScreenState();
}

class _VoiceScanScreenState extends State<VoiceScanScreen>
    with SingleTickerProviderStateMixin {
  final AuthService _auth = AuthService();

  bool _isListening = false;
  bool _micReady = false;
  bool _speechDetected = false;
  bool _phraseMatched = false;

  String _statusText = 'Mic ready karo';
  String _transcript = '';
  BadgeState _badgeState = BadgeState.idle;

  CheckState _micCheck = CheckState.pending;
  CheckState _speechCheck = CheckState.pending;
  CheckState _phraseCheck = CheckState.pending;

  late AnimationController _micAnim;
  String _targetPhrase = 'open duallock';

  @override
  void initState() {
    super.initState();
    _micAnim = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
    _loadPhrase();
  }

  Future<void> _loadPhrase() async {
    _targetPhrase = await _auth.getEnrolledPhrase();
  }

  @override
  void dispose() {
    _auth.stopListening();
    _micAnim.dispose();
    super.dispose();
  }

  Future<void> _startListening() async {
    final permission = await Permission.microphone.request();
    if (!permission.isGranted) {
      _showSnack('❌ Mic permission chahiye!');
      return;
    }

    final initialized = await _auth.initSpeech();
    if (!initialized) {
      _showSnack('❌ Speech recognition nahi chala');
      return;
    }

    setState(() {
      _isListening = true;
      _micReady = true;
      _micCheck = CheckState.ok;
      _badgeState = BadgeState.scanning;
      _statusText = 'Sun raha hun...';
      _transcript = '';
    });

    _micAnim.repeat(reverse: true);
    _showSnack('🎤 Boliye: "${_targetPhrase.toUpperCase()}"');

    await _auth.startListening(
      onResult: (text) {
        if (!mounted) return;
        setState(() {
          _transcript = text;
          if (text.isNotEmpty && !_speechDetected) {
            _speechDetected = true;
            _speechCheck = CheckState.ok;
          }
        });
      },
      onDone: () {
        if (!mounted) return;
        _micAnim.stop();
        setState(() => _isListening = false);
        _checkPhrase(_transcript);
      },
    );
  }

  void _checkPhrase(String spoken) {
    final matched = _auth.matchesPhrase(spoken, _targetPhrase);

    setState(() {
      _phraseCheck = matched ? CheckState.ok : CheckState.fail;
      _badgeState = matched ? BadgeState.success : BadgeState.failed;
      _statusText = matched ? 'Voice verified! ✓' : 'Phrase match nahi hua';
    });

    Future.delayed(const Duration(milliseconds: 800), () {
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        PageRouteBuilder(
          pageBuilder: (_, a, __) => ResultScreen(
            success: matched,
            failReason: matched ? null : 'Aapne bola: "$spoken"\nLekin chahiye tha: "$_targetPhrase"',
          ),
          transitionsBuilder: (_, a, __, child) => FadeTransition(opacity: a, child: child),
        ),
      );
    });
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: GoogleFonts.spaceMono(fontSize: 12)),
        backgroundColor: AppTheme.card,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Voice Verify'),
        automaticallyImplyLeading: false,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const StepIndicator(current: 2, total: 2),
              const SizedBox(height: 20),

              Text(
                'Step 2 — Voice',
                style: GoogleFonts.syne(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  color: AppTheme.textPrimary,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Neeche diya phrase clearly bolein.\nSirf sahi phrase kaam karega.',
                style: GoogleFonts.spaceMono(
                  fontSize: 11,
                  color: AppTheme.textMuted,
                  height: 1.6,
                ),
              ),
              const SizedBox(height: 16),

              StatusBadge(label: _statusText, state: _badgeState),
              const SizedBox(height: 20),

              // Voice card
              SectionCard(
                child: Column(
                  children: [
                    // Mic button
                    GestureDetector(
                      onTap: _isListening ? null : _startListening,
                      child: AnimatedBuilder(
                        animation: _micAnim,
                        builder: (_, child) {
                          final glow = _isListening ? _micAnim.value : 0.0;
                          return Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: AppTheme.card,
                              border: Border.all(
                                color: _isListening ? AppTheme.accent : AppTheme.border,
                                width: 2,
                              ),
                              boxShadow: _isListening
                                  ? [
                                      BoxShadow(
                                        color: AppTheme.accent.withOpacity(0.3 + glow * 0.3),
                                        blurRadius: 20 + glow * 10,
                                        spreadRadius: glow * 4,
                                      )
                                    ]
                                  : [],
                            ),
                            child: Icon(
                              _isListening ? Icons.mic_rounded : Icons.mic_none_rounded,
                              color: _isListening ? AppTheme.accent : AppTheme.textMuted,
                              size: 32,
                            ),
                          );
                        },
                      ),
                    ),

                    const SizedBox(height: 20),

                    // Waveform
                    VoiceWaveform(isActive: _isListening),

                    const SizedBox(height: 16),

                    // Phrase hint
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      decoration: BoxDecoration(
                        color: AppTheme.surface,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: AppTheme.border),
                      ),
                      child: RichText(
                        textAlign: TextAlign.center,
                        text: TextSpan(
                          style: GoogleFonts.spaceMono(fontSize: 11, color: AppTheme.textMuted),
                          children: [
                            const TextSpan(text: 'Boliye: '),
                            TextSpan(
                              text: '"Open DualLock"',
                              style: GoogleFonts.spaceMono(
                                color: AppTheme.accent,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    // Transcript
                    if (_transcript.isNotEmpty) ...[
                      const SizedBox(height: 12),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: AppTheme.surface,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: AppTheme.border),
                        ),
                        child: Text(
                          '"$_transcript"',
                          style: GoogleFonts.spaceMono(
                            fontSize: 11,
                            color: AppTheme.textPrimary,
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),

              const SizedBox(height: 20),

              CheckItem(label: 'Mic access mila', state: _micCheck),
              CheckItem(label: 'Awaaz sun gayi', state: _speechCheck),
              CheckItem(label: 'Phrase match hua', state: _phraseCheck),

              const SizedBox(height: 12),

              if (!_isListening)
                GlowButton(
                  label: _micReady ? 'Dobara Bolo' : 'Bolo Phrase',
                  icon: Icons.mic_rounded,
                  onTap: _startListening,
                ),
            ],
          ),
        ),
      ),
    );
  }
}
