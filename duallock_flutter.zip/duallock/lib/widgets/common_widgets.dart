import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';

// ─── Glowing Button ───────────────────────────────────────────────────────────
class GlowButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback? onTap;
  final Color color;
  final bool outline;

  const GlowButton({
    super.key,
    required this.label,
    required this.icon,
    this.onTap,
    this.color = AppTheme.accent,
    this.outline = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: outline ? Colors.transparent : color,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: outline ? AppTheme.border : Colors.transparent,
          ),
          boxShadow: onTap != null && !outline
              ? [BoxShadow(color: color.withOpacity(0.3), blurRadius: 20, spreadRadius: -4, offset: const Offset(0, 6))]
              : [],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 18, color: outline ? AppTheme.textPrimary : AppTheme.bg),
            const SizedBox(width: 10),
            Text(
              label,
              style: GoogleFonts.spaceMono(
                fontWeight: FontWeight.w700,
                fontSize: 13,
                color: outline ? AppTheme.textPrimary : AppTheme.bg,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Status Badge ─────────────────────────────────────────────────────────────
enum BadgeState { idle, scanning, success, failed }

class StatusBadge extends StatelessWidget {
  final String label;
  final BadgeState state;

  const StatusBadge({super.key, required this.label, required this.state});

  @override
  Widget build(BuildContext context) {
    final color = switch (state) {
      BadgeState.idle => AppTheme.textMuted,
      BadgeState.scanning => AppTheme.accent,
      BadgeState.success => AppTheme.success,
      BadgeState.failed => AppTheme.danger,
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (state == BadgeState.scanning)
            _PulsingDot(color: color)
          else
            Container(width: 6, height: 6, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
          const SizedBox(width: 8),
          Text(
            label,
            style: GoogleFonts.spaceMono(
              fontSize: 10,
              fontWeight: FontWeight.w700,
              color: color,
              letterSpacing: 0.8,
            ),
          ),
        ],
      ),
    );
  }
}

class _PulsingDot extends StatefulWidget {
  final Color color;
  const _PulsingDot({required this.color});

  @override
  State<_PulsingDot> createState() => _PulsingDotState();
}

class _PulsingDotState extends State<_PulsingDot> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: Tween(begin: 0.3, end: 1.0).animate(_ctrl),
      child: Container(width: 6, height: 6, decoration: BoxDecoration(color: widget.color, shape: BoxShape.circle)),
    );
  }
}

// ─── Check Item ───────────────────────────────────────────────────────────────
enum CheckState { pending, ok, fail }

class CheckItem extends StatelessWidget {
  final String label;
  final CheckState state;

  const CheckItem({super.key, required this.label, required this.state});

  @override
  Widget build(BuildContext context) {
    final color = switch (state) {
      CheckState.pending => AppTheme.textMuted,
      CheckState.ok => AppTheme.success,
      CheckState.fail => AppTheme.danger,
    };
    final icon = switch (state) {
      CheckState.pending => '?',
      CheckState.ok => '✓',
      CheckState.fail => '✗',
    };

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.border),
      ),
      child: Row(
        children: [
          Container(
            width: 22,
            height: 22,
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              shape: BoxShape.circle,
            ),
            alignment: Alignment.center,
            child: Text(icon, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.bold)),
          ),
          const SizedBox(width: 12),
          Text(label, style: GoogleFonts.spaceMono(fontSize: 12, color: AppTheme.textPrimary)),
        ],
      ),
    );
  }
}

// ─── Section Card ─────────────────────────────────────────────────────────────
class SectionCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;

  const SectionCard({super.key, required this.child, this.padding});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: padding ?? const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.border),
      ),
      child: child,
    );
  }
}

// ─── Waveform Widget ──────────────────────────────────────────────────────────
class VoiceWaveform extends StatefulWidget {
  final bool isActive;
  const VoiceWaveform({super.key, required this.isActive});

  @override
  State<VoiceWaveform> createState() => _VoiceWaveformState();
}

class _VoiceWaveformState extends State<VoiceWaveform> with TickerProviderStateMixin {
  late List<AnimationController> _controllers;
  late List<Animation<double>> _animations;
  static const int bars = 9;

  @override
  void initState() {
    super.initState();
    _controllers = List.generate(
      bars,
      (i) => AnimationController(
        vsync: this,
        duration: Duration(milliseconds: 300 + i * 50),
      )..repeat(reverse: true),
    );
    _animations = _controllers.map((c) => Tween(begin: 4.0, end: 28.0).animate(c)).toList();
  }

  @override
  void didUpdateWidget(VoiceWaveform old) {
    super.didUpdateWidget(old);
    for (final c in _controllers) {
      widget.isActive ? c.repeat(reverse: true) : c.stop();
    }
  }

  @override
  void dispose() {
    for (final c in _controllers) c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 40,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: List.generate(bars, (i) {
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 2),
            child: AnimatedBuilder(
              animation: _animations[i],
              builder: (_, __) => Container(
                width: 3,
                height: widget.isActive ? _animations[i].value : 4,
                decoration: BoxDecoration(
                  color: widget.isActive
                      ? AppTheme.accent.withOpacity(0.9)
                      : AppTheme.textMuted.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

// ─── Step Indicator ───────────────────────────────────────────────────────────
class StepIndicator extends StatelessWidget {
  final int current; // 1-based
  final int total;

  const StepIndicator({super.key, required this.current, required this.total});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(total * 2 - 1, (i) {
        if (i.isOdd) {
          // Line
          final stepIndex = (i ~/ 2) + 1;
          final done = current > stepIndex;
          return AnimatedContainer(
            duration: const Duration(milliseconds: 400),
            width: 28,
            height: 1,
            color: done ? AppTheme.success : AppTheme.border,
          );
        } else {
          // Dot
          final stepNum = i ~/ 2 + 1;
          final isDone = current > stepNum;
          final isActive = current == stepNum;
          return AnimatedContainer(
            duration: const Duration(milliseconds: 400),
            width: isActive ? 24 : 8,
            height: 8,
            decoration: BoxDecoration(
              color: isDone
                  ? AppTheme.success
                  : isActive
                      ? AppTheme.accent
                      : AppTheme.textMuted,
              borderRadius: BorderRadius.circular(4),
              boxShadow: isActive
                  ? [BoxShadow(color: AppTheme.accent.withOpacity(0.5), blurRadius: 8)]
                  : null,
            ),
          );
        }
      }),
    );
  }
}
