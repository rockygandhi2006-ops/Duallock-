import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // Colors
  static const Color bg = Color(0xFF060A0F);
  static const Color surface = Color(0xFF0D1520);
  static const Color card = Color(0xFF111C2D);
  static const Color accent = Color(0xFF00E5FF);
  static const Color accent2 = Color(0xFF7B2FFF);
  static const Color success = Color(0xFF00FF88);
  static const Color danger = Color(0xFFFF3D71);
  static const Color textPrimary = Color(0xFFE8F0FE);
  static const Color textMuted = Color(0xFF4A6080);
  static const Color border = Color(0xFF1A2A40);

  static ThemeData get theme => ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: bg,
        colorScheme: const ColorScheme.dark(
          primary: accent,
          secondary: accent2,
          surface: surface,
          error: danger,
        ),
        textTheme: GoogleFonts.spaceMonoTextTheme().apply(
          bodyColor: textPrimary,
          displayColor: textPrimary,
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: bg,
          elevation: 0,
          centerTitle: true,
          titleTextStyle: GoogleFonts.syne(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            color: textPrimary,
          ),
          iconTheme: const IconThemeData(color: textPrimary),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: accent,
            foregroundColor: bg,
            minimumSize: const Size(double.infinity, 52),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
            textStyle: GoogleFonts.spaceMono(
              fontWeight: FontWeight.w700,
              fontSize: 13,
              letterSpacing: 0.5,
            ),
          ),
        ),
      );
}
