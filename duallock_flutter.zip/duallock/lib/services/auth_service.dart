import 'dart:typed_data';
import 'package:camera/camera.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart';

enum AuthStatus { idle, scanning, success, failed }

class AuthService {
  // ─── Face Detection ───────────────────────────────────────────
  final FaceDetector _faceDetector = FaceDetector(
    options: FaceDetectorOptions(
      enableClassification: true,
      enableLandmarks: true,
      performanceMode: FaceDetectorMode.accurate,
      minFaceSize: 0.15,
    ),
  );

  Future<List<Face>> detectFaces(CameraImage image, InputImageRotation rotation) async {
    final inputImage = _buildInputImage(image, rotation);
    return await _faceDetector.processImage(inputImage);
  }

  InputImage _buildInputImage(CameraImage image, InputImageRotation rotation) {
    final bytes = _concatenatePlanes(image.planes);
    final metadata = InputImageMetadata(
      size: Size(image.width.toDouble(), image.height.toDouble()),
      rotation: rotation,
      format: InputImageFormat.nv21,
      bytesPerRow: image.planes[0].bytesPerRow,
    );
    return InputImage.fromBytes(bytes: bytes, metadata: metadata);
  }

  Uint8List _concatenatePlanes(List<Plane> planes) {
    final allBytes = WriteBuffer();
    for (final plane in planes) {
      allBytes.putUint8List(plane.bytes);
    }
    return allBytes.done().buffer.asUint8List();
  }

  /// Check if face is valid (frontal, eyes open, good confidence)
  bool isFaceValid(Face face) {
    final leftEyeOpen = face.leftEyeOpenProbability ?? 0;
    final rightEyeOpen = face.rightEyeOpenProbability ?? 0;
    final headEulerY = face.headEulerAngleY ?? 0; // left-right
    final headEulerX = face.headEulerAngleX ?? 0; // up-down

    return leftEyeOpen > 0.6 &&
        rightEyeOpen > 0.6 &&
        headEulerY.abs() < 20 &&
        headEulerX.abs() < 15;
  }

  // ─── Enrolled Face Hash (simple demo) ────────────────────────
  Future<void> enrollFace(String hash) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('enrolled_face_hash', hash);
  }

  Future<bool> hasFaceEnrolled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.containsKey('enrolled_face_hash');
  }

  Future<void> clearEnrolled() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('enrolled_face_hash');
    await prefs.remove('enrolled_phrase');
  }

  // ─── Voice / Phrase ──────────────────────────────────────────
  static const String _defaultPhrase = 'open duallock';
  final SpeechToText _speech = SpeechToText();

  Future<bool> initSpeech() => _speech.initialize(
        onError: (e) => debugPrint('Speech error: $e'),
      );

  Future<void> startListening({
    required Function(String transcript) onResult,
    required VoidCallback onDone,
  }) async {
    await _speech.listen(
      onResult: (result) {
        onResult(result.recognizedWords);
        if (result.finalResult) onDone();
      },
      listenFor: const Duration(seconds: 8),
      pauseFor: const Duration(seconds: 3),
      localeId: 'en_US',
    );
  }

  void stopListening() => _speech.stop();

  Future<String> getEnrolledPhrase() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('enrolled_phrase') ?? _defaultPhrase;
  }

  Future<void> setEnrolledPhrase(String phrase) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('enrolled_phrase', phrase.toLowerCase().trim());
  }

  bool matchesPhrase(String spoken, String target) {
    final s = spoken.toLowerCase().trim();
    final t = target.toLowerCase().trim();
    // Fuzzy: exact match or contains
    return s == t || s.contains(t) || t.contains(s);
  }

  void dispose() {
    _faceDetector.close();
    _speech.cancel();
  }
}
