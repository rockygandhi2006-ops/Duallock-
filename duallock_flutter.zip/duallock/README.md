# 🔐 DualLock — Face + Voice Authentication App

**Face aur Voice dono chahiye — sirf ek se nahi chalega!**

---

## 📱 App Screens

| Screen | Description |
|--------|-------------|
| Welcome | App ka main screen, unlock aur setup buttons |
| Face Scan | Camera se real-time face detection |
| Voice Scan | Speech recognition se phrase verify |
| Result | Success ya fail screen with session timer |
| Setup | Face enroll aur phrase customize karo |

---

## 🚀 Setup Kaise Karo (Step by Step)

### Step 1 — Flutter Install Karo
```bash
# Flutter SDK download karo
# https://docs.flutter.dev/get-started/install

# Check karo
flutter doctor
```

### Step 2 — Project Setup
```bash
# Project folder mein jao
cd duallock

# Dependencies install karo
flutter pub get
```

### Step 3 — Android Run Karo
```bash
# Android emulator ya device connect karo
flutter run
```

### Step 4 — iOS Run Karo (Mac pe)
```bash
# iOS simulator ya device pe
cd ios && pod install && cd ..
flutter run
```

---

## 📦 Dependencies

| Package | Kaam |
|---------|------|
| `google_mlkit_face_detection` | Real-time face detection |
| `camera` | Camera preview aur image stream |
| `speech_to_text` | Voice recognition |
| `permission_handler` | Camera aur mic permissions |
| `shared_preferences` | Enrolled data save karo |
| `google_fonts` | Syne + Space Mono fonts |
| `animate_do` | Smooth animations |

---

## 🔧 App Ka Flow

```
Welcome Screen
     ↓
Face Scan Screen
  → Camera khulta hai
  → ML Kit face detect karta hai
  → Eyes open, frontal face check
  → Face verified ✓
     ↓
Voice Scan Screen
  → Mic permission
  → Speech recognition
  → Phrase match check
  → Voice verified ✓
     ↓
Result Screen
  → Success: 30 second session
  → Fail: Reason batata hai
```

---

## ⚙️ Customization

### Voice Phrase Badlo
Setup screen mein jao → Voice Phrase → apna phrase type karo → Save.

### Default phrase: `"Open DualLock"`

---

## 📋 Permissions Needed

### Android
- `CAMERA` — Face scan ke liye
- `RECORD_AUDIO` — Voice ke liye
- `INTERNET` — ML Kit model download

### iOS
- Camera usage description
- Microphone usage description
- Speech recognition description

---

## 🔮 Future Features (Version 2.0)

- [ ] Actual face embedding store karna (not just detect)
- [ ] Multiple users support
- [ ] App lock (specific apps lock karo)
- [ ] Failed attempts log
- [ ] PIN fallback
- [ ] Dark/Light theme toggle

---

## 👨‍💻 Tech Stack

- **Framework:** Flutter 3.x
- **Language:** Dart
- **Face AI:** Google ML Kit Face Detection
- **Voice AI:** Flutter Speech to Text
- **Storage:** SharedPreferences
- **Fonts:** Google Fonts (Syne + Space Mono)

---

*DualLock — Sirf aapka chehra aur aapki awaaz!* 🔐
